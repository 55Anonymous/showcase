#define pthread_create a5_pthread_create
#define accept a5_accept