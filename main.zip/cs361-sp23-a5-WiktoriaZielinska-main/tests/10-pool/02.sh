#!/bin/bash

grep "TEST 05-file PASSING" results
grep "TEST 06-ping-echo-write-read-file PASSING" results
grep "TEST 07-write-write-write PASSING" results
grep "TEST 08-stats PASSING" results