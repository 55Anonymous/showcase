#!/bin/bash

grep "TEST 01-accept-ping PASSING" results
grep "TEST 02-pending-accept PASSING" results
grep "TEST 03-many-pending-accept PASSING" results
grep "TEST 04-ping-echo PASSING" results